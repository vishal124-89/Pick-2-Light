/*
 * File:   main.c
 * Author: Vishal
 *
 * Created on 5 June, 2024, 3:07 PM
 */


#include <xc.h>
#include "external_interrupt.h"
#include "main.h"
#include "digital_keypad.h"
#include "ssd_display.h"
#include "eeprom.h"
#include "can.h"
#include "uart.h"
#include <string.h>

unsigned int key_detected=0;
static unsigned char ssd[MAX_SSD_CNT];
static unsigned char mode[] = {U, DASH, S, T, N, I, D};
char key=ALL_RELEASED;
char flag=0,e_flag=0;
static unsigned char check[5];

void init_config(void) {
    TRISB0 = 1;
    PEIE = 1;
    ADCON1 = 0x0F;
    init_ssd_control();
    init_external_interrupt();
    init_digital_keypad();
    GIE = 1;
        //n-id
        write_internal_eeprom(0x00, '1');
        write_internal_eeprom(0x01, '2');
        write_internal_eeprom(0x02, '3');
        write_internal_eeprom(0x03, '4');
        //u-st
        write_internal_eeprom(0x04, '5');
        write_internal_eeprom(0x05, '6');
        write_internal_eeprom(0x06, '7');
        write_internal_eeprom(0x07, '8');
        init_can();
}

void main(void) {
    init_config();
  
    while (1) {
        if (key_detected) 
        {
           
           key = read_digital_keypad(STATE_CHANGE);
            if(e_flag==0)
            {
                 if (key == SWITCH3 ) {
                flag = !flag;
                }

                if (flag == 0) {
                ssd[0] = mode[0];
                ssd[1] = mode[1];
                ssd[2] = mode[2];
                ssd[3] = mode[3];
                }
                 
                if (flag == 1) {
                ssd[0] = mode[4];
                ssd[1] = mode[1];
                ssd[2] = mode[5];
                ssd[3] = mode[6];
                }
 
                if (key == SWITCH2) 
                {
                    e_flag = !e_flag;
                }
                      display(ssd);
            }
            else
            {
                if(flag == 0)
                {
                    u_st(key);
                }
                if(flag == 1)
                {
                    n_id(key);
                }
                
            }
        }
        else
        {
            PORTA=0x00;
        }
        if (can_receive()) 
        {
                check[0] = read_internal_eeprom(0x00) - 48;
                check[1] = read_internal_eeprom(0x01) - 48;
                check[2] = read_internal_eeprom(0x02) - 48;
                check[3] = read_internal_eeprom(0x03) - 48;
                check[4] = '\0';
                if (!strcmp(rcv_node, check)) 
                {
                    write_internal_eeprom(0x04, rcv_count[0]);
                    write_internal_eeprom(0x04, rcv_count[1]);
                    write_internal_eeprom(0x04, rcv_count[2]);
                    write_internal_eeprom(0x04, rcv_count[3]);

                    u_st(key);
                    flag = 0;
                    e_flag=0;
                    key_detected  = !key_detected; 
            }
        }

    }
return;
}
