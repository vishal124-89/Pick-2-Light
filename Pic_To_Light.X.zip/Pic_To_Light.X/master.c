/*
 * File:   master.c
 * Author: Vishal
 *
 * Created on 11 June, 2024, 3:52 PM
 */


#include <xc.h>
#include "main.h"
#include "uart.h"
#include "can.h"

/*extern char rcv_data[8];
extern char tmt_data[8];
unsigned char ch;

void init_master() 
{  
    init_uart();
    init_can();
}

void master_(void) 
{
    init_master();
    static int i = 0, char_count = 0,once = 1;
    while (1)
    {
        if (can_receive())
        {
           puts("Received data.\n\r");
            puts("node-id : ");
            for (int i = 0; i < 4; i++)
                putch(rcv_data[i]);
            puts("\n\r");
            puts("count : ");
                for (int i = 4;i < 8; i++)
            putch(rcv_data[i]);
            
            puts("\n\r");
            
            if(ch)
            {
                puts("Enter the node-id (maximum 4 characters : \n\r");
                tmt_data[0] = ch;
                tmt_data[1] = ch;
                tmt_data[2] = ch;
                tmt_data[3] = ch;
                puts("\n\r");
                puts("Enter the count (maximum 4 characters : \n\r");
                tmt_data[4] = ch;
                tmt_data[5] = ch;
                tmt_data[6] = ch;
                tmt_data[7] = ch;
                puts("\n\r");
                
                can_transmit();
            }
        }
    }
}*/
