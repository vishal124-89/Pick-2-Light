#include <xc.h>
#include "isr.h"

extern unsigned int key_detected;
extern char flag;
extern char e_flag;

void __interrupt() isr(void)
{
	if (INT0F == 1)
	{
		key_detected = !key_detected;
        flag=0;
        e_flag=0;

		INT0F = 0;
	}
}


