#ifndef MAIN
#define MAIN

void u_st(char key);
void n_id(char key);

static unsigned char node[5];
 char rcv_count[5];
 char rcv_node[5];
 void u_st(char key);
 void n_id(char key);
#endif